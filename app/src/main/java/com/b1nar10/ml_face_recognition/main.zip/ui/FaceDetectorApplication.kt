package com.b1nar10.ml_face_recognition.ui

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FaceDetectorApplication : Application() {
}